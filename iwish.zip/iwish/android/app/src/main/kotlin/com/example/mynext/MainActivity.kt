package com.example.mynext

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
